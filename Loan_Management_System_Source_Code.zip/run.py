from loan import loan
from loan.controllers import  customer_controller, officer_controller, loan_controller, home_controller
    
    
if __name__ == "__main__":    
    # loan.run(debug=True)
    loan.run()
