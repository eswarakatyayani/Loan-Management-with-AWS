
from flask import Flask
from flask_pymongo import PyMongo
from flask_jwt_extended import JWTManager 
# import certifi



loan = Flask(__name__)
loan.config["MONGO_URI"] = ""
loan.config['JWT_SECRET_KEY'] = ""


loan.secret_key = "mysecret"
# ca = certifi.where()

mongo = PyMongo(loan)
jwt = JWTManager(loan)

    