from loan import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
class Loan:
    collection = mongo.db.loans

    @classmethod
    def update(cls, loan_id, data):
        return cls.collection.update_one({"_id": ObjectId(loan_id)}, {"$set": data})



    @classmethod
    def create(cls, data):
        result = cls.collection.insert_one(data)
        return result


    @classmethod
    def find(cls, query):
        return cls.collection.find_one(query)
    
    @classmethod
    def get_loans_by_customer_id(cls, customer_id):
        return cls.collection.find({"customer_id": ObjectId(customer_id)})
    
    @classmethod
    def get_pending_loans(cls):
        return cls.collection.find({"loan_status": "pending"})