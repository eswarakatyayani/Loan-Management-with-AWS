from loan import mongo
from werkzeug.security import generate_password_hash, check_password_hash

class Officer:
    collection = mongo.db.officers




    @classmethod
    def create(cls, data):
        return cls.collection.insert_one(data)

    @classmethod
    def get_by_email(cls, email):
        return cls.collection.find_one({"email": email})

    @classmethod
    def check_password(cls, officer, password):
        return check_password_hash(officer["password"], password)

    @classmethod
    def exists_by_email(cls, email):
        return cls.collection.find_one({"email": email}) is not None