from loan import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
class Account:
    collection = mongo.db.accounts


    @classmethod
    def create(cls, data):
        result = cls.collection.insert_one(data)
        return result
    

    @classmethod
    def find(cls, query):
        result = cls.collection.find_one(query)
        return result
    
    @classmethod
    def find_by_id(cls, account_id):
        return cls.collection.find_one({"_id": ObjectId(account_id)})