from loan import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
class Customer:
    collection = mongo.db.customers


    @classmethod
    def delete(cls, customer_id):
        return cls.collection.delete_one({"_id": ObjectId(customer_id)})

    @classmethod
    def create(cls, data):
        return cls.collection.insert_one(data)

    @classmethod
    def get_by_email(cls, email):
        return cls.collection.find_one({"email": email})

    @classmethod
    def check_password(cls, customer, password):
        return check_password_hash(customer["password"], password)

    @classmethod
    def exists_by_email(cls, email):
        return cls.collection.find_one({"email": email}) is not None
    

    @classmethod
    def get_all(cls):
        return cls.collection.find()
    
    @classmethod
    def get_by_id(cls, customer_id):
        return cls.collection.find_one({"_id": ObjectId(customer_id)})

    @classmethod
    def update(cls, customer_id, data):
        return cls.collection.update_one({"_id": ObjectId(customer_id)}, {"$set": data})
    

    @classmethod
    def find_by_id(cls, customer_id):
        return cls.collection.find_one({"_id": ObjectId(customer_id)})