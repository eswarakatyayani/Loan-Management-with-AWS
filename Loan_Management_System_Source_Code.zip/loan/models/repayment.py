from loan import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
class Repayment:
    collection = mongo.db.repayments
