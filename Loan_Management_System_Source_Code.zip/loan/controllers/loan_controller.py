from flask import render_template, request, redirect, url_for, session
from loan import loan
from loan.models.officer import Officer
from loan.models.customer import Customer 
from loan.models.loan import Loan
from loan.models.property import Property
from loan.models.account import Account
from loan.models.repayment import Repayment
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)









@loan.route('/customer_apply_loan', methods=['GET', 'POST'])
def customer_apply_loan():
    try:
        if request.method == 'POST':
            # Extract loan application form data
            amount_requested = request.form.get("amount_requested").strip()
            term = request.form.get("term").strip()
            downpayment = request.form.get("downpayment").strip()
            roi = "0.0"
            date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            loan_status = "pending"  # Default status 
            # Extract property form data
            property_address = request.form.get("property_address").strip()
            city = request.form.get("city").strip()
            property_type = request.form.get("property_type").strip()
            county = request.form.get("county").strip()
            zipcode = request.form.get("zipcode").strip()
            current_market_price = request.form.get("current_market_price").strip()
            other_details = request.form.get("other_details").strip() 
            # bank details
            bank_name = request.form.get("bank_name").strip()
            account_number = request.form.get("account_number").strip()
            account_name = request.form.get("account_name").strip()
            account_type = request.form.get("account_type").strip()
            ifsc_code = request.form.get("ifsc_code").strip() 

            # Check if customer is logged in
            if 'customer_id' not in session:
                flash("You need to log in to apply for a loan.")
                return redirect(url_for('customer_login'))

            # Prepare data for new loan application
            loan_data = {
                "amount_requested": amount_requested,
                "term": term,
                "downpayment": downpayment,
                "roi": roi,
                "date": date,
                "loan_status": loan_status,
                "customer_id": ObjectId(session['customer_id'])
            }
            loan_result = Loan.create(loan_data)
            if not loan_result:
                flash("Loan application failed.")
                return redirect(url_for('customer_apply_loan'))

            loan_id = loan_result.inserted_id
            flash("Loan application submitted successfully.")
            property_data = {
                "address": property_address,
                "city": city,
                "type": property_type,
                "county": county,
                "zipcode": zipcode,
                "current_market_price": current_market_price,
                "other_details": other_details,
                "loan_id": loan_id,
                "customer_id": ObjectId(session['customer_id'])
            }
            property_result = Property.create(property_data)
            if not property_result:
                flash("Property registration failed.")
                return redirect(url_for('customer_apply_loan'))
            property_id = property_result.inserted_id
            account_data = {
                "bank_name": bank_name,
                "account_number": account_number,
                "account_name": account_name,
                "account_type": account_type,
                "ifsc_code": ifsc_code,
                "loan_id": loan_id,
                "customer_id": ObjectId(session['customer_id'])
            }
            account_result = Account.create(account_data)
            if not account_result:
                flash("Account registration failed.")
                return redirect(url_for('customer_apply_loan'))

            account_id = account_result.inserted_id

            #  to loan insert property_id and account_id
            Loan.update(loan_id, {"property_id": property_id, "account_id": account_id})
            flash("Loan application submitted successfully.")
            return redirect(url_for('customer_home'))

        # Render the loan application page if method is GET
        return render_template('loans/customer_apply_loan.html')
    except Exception as e:
        logger.error(f"Error during customer loan application: {str(e)}")
        return "Internal Server Error", 500
    

@loan.route('/customer_view_loans', methods=['GET'])
def customer_view_loans():
    try:
        if 'customer_id' not in session:
            flash("You need to log in to view your loans.")
            return redirect(url_for('customer_login'))

        customer_id = ObjectId(session['customer_id'])
        loans = Loan.get_loans_by_customer_id(customer_id)
        loans = list(loans)

        # Enhance loans with property and account details
        for loan in loans:
            # Fetch property details
            property_id = loan.get('property_id')
            if property_id:
                loan['property'] = Property.find_by_id(property_id)

            # Fetch account details
            account_id = loan.get('account_id')
            if account_id:
                loan['account'] = Account.find_by_id(account_id)

        return render_template('loans/customer_view_loans.html', loans=loans)
    except Exception as e:
        logger.error(f"Error during customer loan view: {str(e)}")
        return "Internal Server Error", 500


@loan.route('/officer_view_pending_loans', methods=['GET'])
def officer_view_pending_loans():
    try:
        if 'officer_id' not in session:
            flash("You need to log in to view pending loans.")
            return redirect(url_for('officer_login'))

        loans = Loan.get_pending_loans()
        loans = list(loans)

        # Enhance loans with customer, property, and account details
        for loan in loans:
            # Fetch customer details
            customer_id = loan.get('customer_id')
            if customer_id:
                loan['customer'] = Customer.find_by_id(customer_id)

            # Fetch property details
            property_id = loan.get('property_id')
            if property_id:
                loan['property'] = Property.find_by_id(property_id)
            
            # Fetch account details
            account_id = loan.get('account_id')
            if account_id:
                loan['account'] = Account.find_by_id(account_id)
            
        return render_template('loans/officer_view_pending_loans.html', loans=loans)
    except Exception as e:
        logger.error(f"Error during officer pending loan view: {str(e)}")
        return "Internal Server Error", 500
    

@loan.route('/update_loan_term_details/<loan_id>', methods=['POST'])
def update_loan_term_details(loan_id):
    term = request.form['term'].strip() 
    # Logic to update the loan details in the database
    # update loan
    Loan.update(loan_id, {"term": term})
    return redirect(url_for('officer_view_pending_loans'))

@loan.route('/update_loan_roi_details/<loan_id>', methods=['POST'])
def update_loan_roi_details(loan_id):
    roi = request.form['roi'].strip()
    # Logic to update the loan details in the database
    # update loan
    Loan.update(loan_id, {"roi": roi})
    return redirect(url_for('officer_view_pending_loans'))


@loan.route('/update_loan_status/<loan_id>', methods=['POST'])
def update_loan_status(loan_id):
    new_status = request.form['status']
    # Logic to update the loan status in the database
    Loan.update(loan_id, {"loan_status": new_status})
    return redirect(url_for('officer_view_pending_loans'))
