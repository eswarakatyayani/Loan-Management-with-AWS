from flask import render_template, request, redirect, url_for, session
from loan import loan
from loan.models.officer import Officer
from loan.models.customer import Customer 
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



@loan.route('/customer_create', methods=['GET', 'POST'])
def customer_create():
    try:
        if request.method == 'POST':
            # Extract form data
            first_name = request.form.get("firstname").strip()
            last_name = request.form.get("lastname").strip()
            email = request.form.get("email").strip()
            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()
            address = request.form.get("address").strip()
            mobile = request.form.get("mobile").strip()
            annual_income = request.form.get("incomeAnnual").strip()
            profession = request.form.get("profession").strip()
            ssn = request.form.get("ssn").strip()
            credit_score = request.form.get("creditScore").strip()

            # Check if the email already

            if Customer.exists_by_email(email):
                return "Email already registered", 400
            
            # Check if passwords match
            if password != confirm_password:
                return "Passwords do not match", 400
            
            # Prepare data for new customer registration
            data = {
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "password": generate_password_hash(password),
                "address": address,
                "mobile": mobile,
                "annual_income": annual_income,
                "profession": profession,
                "ssn": ssn,
                "credit_score": credit_score,
                "createdAt": datetime.now()
            }

            # Create new customer record
            Customer.create(data)
            return redirect(url_for('customer_login'))
        
        # Render the registration page if method is GET
        return render_template('customers/customer_create_account.html')
    except Exception as e:
        logger.error(f"Error during customer registration: {str(e)}")
        return "Internal Server Error", 500

@loan.route('/customer_login', methods=['GET', 'POST'])
def customer_login():
    try:
        if request.method == 'POST':
            email = request.form.get("email").strip()
            password = request.form.get("password").strip()

            # Check if the customer exists
            customer = Customer.get_by_email(email)
            if customer is None:
                return "Customer does not exist", 400

            # Check if password matches
            if not check_password_hash(customer['password'], password):
                return "Invalid password", 400

            # Set session variables
            session['customer_id'] = str(customer['_id'])
            session['customer_type'] = 'customer'

            return redirect(url_for('customer_home'))

        # Render the login page if method is GET
        return render_template('customers/customer_login.html')
    except Exception as e:
        logger.error(f"Error during customer login: {str(e)}")
        return "Internal Server Error", 500
    
@loan.route('/customer_home')
def customer_home():
    if 'customer_id' in session:
        return render_template('customers/customer_home.html')
    else:
        return redirect(url_for('login'))
    
