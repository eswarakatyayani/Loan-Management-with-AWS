from flask import render_template, request, redirect, url_for, session
from loan import loan
from loan.models.officer import Officer
from loan.models.customer import Customer 
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@loan.route('/officer_create', methods=['GET', 'POST'])
def officer_create():
    try:
        if request.method == 'POST':
            # Extract form data
            first_name = request.form.get("firstname").strip()
            last_name = request.form.get("lastname").strip()
            email = request.form.get("email").strip()
            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()
            address = request.form.get("address").strip()
            phone = request.form.get("phone").strip()

            # Check if the email already exists
            if Officer.exists_by_email(email):
                return "Email already registered", 400

            # Check if passwords match
            if password != confirm_password:
                return "Passwords do not match", 400

            # Prepare data for new officer registration
            data = {
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "password": generate_password_hash(password),
                "address": address,
                "phone": phone,
                "createdAt": datetime.now()
            }

            # Create new officer record
            Officer.create(data)
            return redirect(url_for('login'))

        # Render the registration page if method is GET
        return render_template('officers/officer_create_account.html')
    except Exception as e:
        logger.error(f"Error during officer registration: {str(e)}")
        return "Internal Server Error", 500

@loan.route('/officer_login', methods=['GET', 'POST'])
def officer_login():
    try:
        if request.method == 'POST':
            email = request.form.get("email").strip()
            password = request.form.get("password").strip()

            # Check if the officer exists
            officer = Officer.get_by_email(email)
            if officer is None:
                return "Officer does not exist", 400

            # Check if the password is correct
            if not check_password_hash(officer['password'], password):
                return "Incorrect password", 400

            # Save officer id in session
            session['officer_id'] = str(officer['_id'])

            return redirect(url_for('officer_home'))

        return render_template('officers/officer_login.html')
    except Exception as e:
        logger.error(f"Error during officer login: {str(e)}")
        return "Internal Server Error", 500

@loan.route('/officer_home')
def officer_home():
    if 'officer_id' in session:
        customers = Customer.get_all()
        total_customers = customers.count()
        return render_template('officers/officer_home.html', total_customers=total_customers)
    else:
        return redirect(url_for('login'))

@loan.route('/officer_add_customer', methods=['GET', 'POST'])
def officer_add_customer():
    if request.method == 'POST':
        try:
            data = {
                "first_name": request.form.get("first_name").strip(),
                "last_name": request.form.get("last_name").strip(),  
                "email": request.form.get("email").strip(),
                "phone_number": request.form.get("phone_number").strip(),
                "address": request.form.get("address").strip(),
                "password": generate_password_hash(request.form.get("password").strip())
            }
            if Customer.exists_by_email(data['email']):
                flash('Email already registered')
                return redirect(url_for('officer_add_customer'))
            Customer.create(data)
            flash('Customer added successfully')
            return redirect(url_for('officer_manage_customers'))
        except Exception as e:
            logger.error(f"Error during adding customer: {str(e)}")
            return "Internal Server Error", 500
    return render_template('officer/add_customer.html')

@loan.route('/officer_edit_customer/<customer_id>', methods=['GET', 'POST'])
def officer_edit_customer(customer_id):
    customer = Customer.get_by_id(customer_id)
    if request.method == 'POST':
        try:
            updated_data = {
                "first_name": request.form.get("first_name").strip(),
                "last_name": request.form.get("last_name").strip(),
                "email": request.form.get("email").strip(),
                "phone_number": request.form.get("phone_number").strip(),
                "address": request.form.get("address").strip(),
                "status": request.form.get("status").strip(),
            }
            Customer.update(customer_id, updated_data)
            flash('Customer updated successfully')
            return redirect(url_for('officer_manage_customers'))
        except Exception as e:
            logger.error(f"Error during updating customer: {str(e)}")
            return "Internal Server Error", 500 
    return render_template('officer/edit_customer.html', customer=customer)

@loan.route('/officer_delete_customer/<customer_id>', methods=['POST'])
def officer_delete_customer(customer_id):
    try:
        Customer.delete(customer_id)
        flash('Customer deleted successfully')
    except Exception as e:
        logger.error(f"Error during deleting customer: {str(e)}")
        flash('Error during customer deletion')
    return redirect(url_for('officer_manage_customers'))

@loan.route('/officer_manage_customers')
def officer_manage_customers():
    customers = Customer.get_all()
    customers = list(customers) 
    return render_template('officer/view_customers.html', customers=customers)


