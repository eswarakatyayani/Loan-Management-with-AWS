from flask import render_template, request, redirect, url_for, session
from loan import loan
from loan.models.officer import Officer
from loan.models.customer import Customer  
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime
from flask import jsonify
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


from flask import redirect, url_for, session



@loan.route('/')
def index():   
    return render_template('index.html')






@loan.route('/logout')
def logout():
    try:
        session.pop('rider_id', None)
        session.pop('rider_type', None)
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error during logout: {str(e)}")
        return "Internal Server Error", 500
